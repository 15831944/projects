#pragma once

#include <TLHELP32.H> 
#include <pdh.h>
#pragma comment(lib,"pdh.lib")
#include <PSAPI.H>
#pragma comment(lib,"psapi.lib")

#include <string>


// ����ָ�����̵ľ����
class CSystemInfo
{
public:
	CSystemInfo(void);
	~CSystemInfo(void);

	BOOL  GetProcessIdByName(LPCTSTR lpszProcessName, DWORD &dwProcessId);
	BOOL  GetProcessIdByName(LPCTSTR lpszProcessName, DWORD *&dwProcessId, unsigned int &count);
	BOOL  GetProcessHandleByName(LPCTSTR lpszProcessName, HANDLE &ProcessHandle);

	//BOOL GetProcHandleAndThreadCount(LPCTSTR lpszProcessName, DWORD &handleNum, DWORD &ThreadNum);
	
	BOOL GetProcHandleAndThreadCount(DWORD &dwProcessId, int &threadcount, DWORD &handleCount);//��ȡ�߳����;����
	BOOL GetMemoryUsage(DWORD ProcessId, ULONG &mem);
	BOOL GetVirtualMemoryUsage(DWORD ProcessId, ULONG &virtualmem);
	BOOL GET_IO_BYTES(DWORD ProcessId, ULONG &read_bytes, ULONG &write_bytes);
	BOOL GET_GDI(DWORD ProcessId, unsigned int &gdiNum);
	BOOL GET_CPU_USAGE(DWORD ProcessId, float &cpu_percent, DWORD dwElapsedTime, static LARGE_INTEGER &ProcessTimeOld);
	//BOOL GET_CPU_USAGE(DWORD ProcessId, float& cpu_percent);
      
	int Get_processor_number();
    ULONG File_time_2_utc(const FILETIME* ftime);
	BOOL GET_USER_Object(DWORD ProcessId, ULONG &UserObjectNum);

	//global
	BOOL GetGlobalValueByPBH(std::string &strValue);
	BOOL GetGlobalMemUse(DWORDLONG &TotalPhyMem, DWORDLONG &AvailPhyMem, DWORD &UsagePhyMem);
//    BOOL GetGlobalCpuUsageAndCpuCount(unsigned short &cpuRate, unsigned &cpuCount);
private:
	
};
