#include "stdAfx.h"
#include "SystemInfo.h"
#include <tchar.h>
#include "console/DebugTools.h"

CSystemInfo::CSystemInfo(void)
{
}

CSystemInfo::~CSystemInfo(void)
{
}


const std::string& StringCat(std::string &srcString, const char *formatString, ...)
{
	va_list args;
	char tempString[2048] = {0};  // ��ʽ���ַ������֧��2048���ֽ�
	va_start(args, formatString);
	vsnprintf(tempString, sizeof(tempString), formatString, args);
	srcString += tempString;
	return srcString;
}

BOOL CSystemInfo::GetProcessIdByName(LPCTSTR lpszProcessName, DWORD &dwProcessId)
{
	dwProcessId = 0;    
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);     
	if (hSnapshot == INVALID_HANDLE_VALUE)     
	{         
		return FALSE;     
	}       
	PROCESSENTRY32 pe;     
	pe.dwSize = sizeof pe;       
	if (Process32First(hSnapshot, &pe))     
	{         
		do 
		{             
			if (lstrcmpi(lpszProcessName, pe.szExeFile) == 0)             
			{                 
				CloseHandle(hSnapshot);                 
				dwProcessId = pe.th32ProcessID;                
				return TRUE;             
			}         
		} while(Process32Next(hSnapshot, &pe));     
	}       
	CloseHandle(hSnapshot);     
	return FALSE; 
}


BOOL CSystemInfo::GetProcessIdByName(LPCTSTR lpszProcessName, DWORD *&dwProcessId, unsigned int &count)
{
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);     
	if (hSnapshot == INVALID_HANDLE_VALUE)     
	{         
		return FALSE;     
	}       
	PROCESSENTRY32 pe;     
	pe.dwSize = sizeof pe;       
	if (Process32First(hSnapshot, &pe))     
	{         
		do 
		{             
			if (lstrcmpi(lpszProcessName, pe.szExeFile) == 0)             
			{                 
				//CloseHandle(hSnapshot);                 
				dwProcessId[count] = pe.th32ProcessID; 
				count++;
				//return TRUE;             
			}         
		} while(Process32Next(hSnapshot, &pe));     
	}       
	CloseHandle(hSnapshot);     
	return TRUE; 
}



BOOL  CSystemInfo::GetProcessHandleByName(LPCTSTR lpszProcessName, HANDLE &ProcessHandle)
{
	BOOL _OK = FALSE;
	DWORD ProcessId = 0;
	ProcessHandle = NULL;
	if (GetProcessIdByName(lpszProcessName, ProcessId))
	{
		ProcessHandle = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);
		_OK = TRUE;
		if(!ProcessHandle)
			CloseHandle(ProcessHandle);
	}
	return _OK;
}

BOOL CSystemInfo::GetMemoryUsage(DWORD ProcessId, ULONG &mem)
{
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);

	if ( !hProcess )
	{
		return FALSE;
	}


	PROCESS_MEMORY_COUNTERS pmc;
	if(GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc)))
	{
		mem = pmc.WorkingSetSize / 1024;
	}

	if(hProcess)
		CloseHandle(hProcess);


	return TRUE;

}

BOOL CSystemInfo::GetVirtualMemoryUsage(DWORD ProcessId, ULONG &virtualmem)
{
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);

	if ( !hProcess )
	{
		return FALSE;
	}


	PROCESS_MEMORY_COUNTERS pmc;
	if(GetProcessMemoryInfo(hProcess, &pmc, sizeof(pmc)))
	{
		virtualmem = pmc.PeakPagefileUsage / 1024;
	}

	if(hProcess)
		CloseHandle(hProcess);


	return TRUE;

}



BOOL CSystemInfo::GET_IO_BYTES(DWORD ProcessId, ULONG &read_bytes, ULONG &write_bytes)
{
	IO_COUNTERS io_counter;

	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);

	if ( !hProcess )
	{
		return FALSE;
	}

	if(GetProcessIoCounters(hProcess, &io_counter))
	{
		read_bytes = io_counter.ReadTransferCount / 1024;
		write_bytes = io_counter.WriteTransferCount / 1024;
	}

	if(hProcess)
		CloseHandle(hProcess);
	return TRUE;
}

BOOL CSystemInfo::GET_GDI(DWORD ProcessId, unsigned int &gdiNum)
{
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);

	if ( !hProcess )
	{
		return FALSE;
	}

	gdiNum = ::GetGuiResources (hProcess, GR_GDIOBJECTS);

	if(hProcess)
		CloseHandle(hProcess);

	return TRUE;
}

int CSystemInfo::Get_processor_number()
{
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	return (int)info.dwNumberOfProcessors;
}

ULONG CSystemInfo::File_time_2_utc(const FILETIME* ftime)
{
	LARGE_INTEGER li;

	//assert(ftime);
	li.LowPart = ftime->dwLowDateTime;
	li.HighPart = ftime->dwHighDateTime;
	return li.QuadPart;
}

BOOL CSystemInfo::GET_CPU_USAGE(DWORD ProcessId, float &cpu_percent, DWORD dwElapsedTime, static LARGE_INTEGER &ProcessTimeOld)
{
	//cpu����
	int processor_count_ = Get_processor_number();

	FILETIME CreateTime, ExitTime, KernelTime,UserTime;
	LARGE_INTEGER lgKernelTime;
	LARGE_INTEGER lgUserTime;
	LARGE_INTEGER lgCurTime;


	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION , FALSE, ProcessId);
	if ( !hProcess )
	{
		DWORD last_error = GetLastError();
		return FALSE;
	}
	BOOL bRetCode = GetProcessTimes(hProcess, &CreateTime, &ExitTime, &KernelTime, &UserTime);

	if(hProcess)
		CloseHandle(hProcess);
	if (bRetCode)
	{
		lgKernelTime.HighPart = KernelTime.dwHighDateTime;
		lgKernelTime.LowPart = KernelTime.dwLowDateTime;

		lgUserTime.HighPart = UserTime.dwHighDateTime;
		lgUserTime.LowPart = UserTime.dwLowDateTime;

		lgCurTime.QuadPart = (lgKernelTime.QuadPart + lgUserTime.QuadPart) / 10000.0;
		cpu_percent = (lgCurTime.QuadPart - ProcessTimeOld.QuadPart) * 100.0 / (float)dwElapsedTime;
		ProcessTimeOld = lgCurTime;
		cpu_percent = cpu_percent / (float)processor_count_;
		return TRUE;
	}
	else
	{
		cpu_percent = 0.0;
		return FALSE;
	}
}


BOOL CSystemInfo::GetProcHandleAndThreadCount(DWORD &dwProcessId, int &threadcount, DWORD &handleCount)
{ 
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);     
	if (hSnapshot == INVALID_HANDLE_VALUE)     
	{         
		return FALSE;     
	}       
	PROCESSENTRY32 pe;     
	pe.dwSize = sizeof pe;       
	if (Process32First(hSnapshot, &pe))     
	{         
		do 
		{             
			if ( dwProcessId == pe.th32ProcessID )             
			{    
				threadcount = (int)pe.cntThreads;
				HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, dwProcessId);
				GetProcessHandleCount(hProcess, &handleCount);
				CloseHandle(hSnapshot);                                
				return TRUE;             
			}         
		} while(Process32Next(hSnapshot, &pe));     
	} 

	CloseHandle(hSnapshot); 
	return FALSE;
}


BOOL CSystemInfo::GET_USER_Object(DWORD ProcessId, ULONG &UserObjectNum)
{
	HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessId);

	if ( !hProcess )
	{
		return FALSE;
	}

	UserObjectNum = ::GetGuiResources (hProcess, GR_USEROBJECTS);

	if(hProcess)
		CloseHandle(hProcess);

	return TRUE;
}

BOOL CSystemInfo::GetGlobalMemUse(DWORDLONG &TotalPhyMem, DWORDLONG &AvailPhyMem, DWORD &UsagePhyMem)
{
	MEMORYSTATUSEX statex;
	statex.dwLength = sizeof (statex);
	if(FALSE == GlobalMemoryStatusEx(&statex))
		return FALSE;

	TotalPhyMem = statex.ullTotalPhys;
	AvailPhyMem = statex.ullAvailPhys;
	UsagePhyMem = statex.dwMemoryLoad;
	return TRUE;
}

/*************************************************
// <Summary>get performance data of the system by the PBH method  </Summary>
// <DateTime>2014/12/01</DateTime>
// <Parameter name="strValue" type="OUT/IN">return formatted data (XML format)</Parameter>
// <Returns>TRUE/FALSE</Returns>
*************************************************/
BOOL CSystemInfo::GetGlobalValueByPBH(std::string &strValue)
{
	BOOL bResult = FALSE;
	SYSTEM_INFO systemInfo;
	GetSystemInfo(&systemInfo);
	//cpuCount = systemInfo.dwNumberOfProcessors;

	PDH_STATUS pdhStatus = ERROR_SUCCESS;  // PDH state
	HQUERY hQuery = NULL;                  // pdh query handle
	HCOUNTER hProTimeCounter = NULL;       // processor time counter handle
	HCOUNTER hDiskTimeCounter = NULL;      // disk time counter handle
	HCOUNTER hAvaiMemCounter = NULL;       // available memory (MB) counter handle
	PDH_FMT_COUNTERVALUE displayValue;     // counter value

	do 
	{
		if (PdhOpenQueryA(NULL, 0, &hQuery) == ERROR_SUCCESS)  // open query handle
		{
			// add counter to query handle
		//	"\\Processor Information(_Total)\\% Processor Time"

			if(ERROR_SUCCESS == PdhAddCounterA(hQuery,"\\Process(RTX)\\% Processor Time", 0, &hProTimeCounter)
				&& ERROR_SUCCESS == PdhAddCounterA(hQuery, "\\PhysicalDisk(_Total)\\% Disk Time", 0, &hDiskTimeCounter)
				&& ERROR_SUCCESS == PdhAddCounterA(hQuery, "\\Memory\\Available MBytes", 0, &hAvaiMemCounter))
			{
				//first collect data
				PdhCollectQueryData(hQuery);
				Sleep(1000);
				//second collect data
				PdhCollectQueryData(hQuery);

				//get processor time value
				pdhStatus = PdhGetFormattedCounterValue(hProTimeCounter, PDH_FMT_LONG, NULL, &displayValue);
				if (ERROR_SUCCESS != pdhStatus)
					break;

				if (strValue.empty())
					StringCat(strValue, "cpu time: %d", displayValue.longValue);
				else
					StringCat(strValue, " cpu time: %d", displayValue.longValue);



				//get disk timer value
				pdhStatus = PdhGetFormattedCounterValue(hDiskTimeCounter, PDH_FMT_LONG, NULL, &displayValue);
				if (ERROR_SUCCESS != pdhStatus)
					break;

				if (strValue.empty())
					StringCat(strValue, "disk time: %d", displayValue.longValue);
				else
					StringCat(strValue, " disk time: %d", displayValue.longValue);


				//get available memory
				pdhStatus = PdhGetFormattedCounterValue(hAvaiMemCounter, PDH_FMT_LONG, NULL, &displayValue);
				if (ERROR_SUCCESS != pdhStatus)
					break;
 
				if (strValue.empty())
					StringCat(strValue, "available memory: %d", displayValue.longValue);
				else
					StringCat(strValue, " available memory: %d", displayValue.longValue);

				bResult = TRUE;
			}
		}
	} while (false);

	if (hQuery)
		PdhCloseQuery (hQuery);

	return bResult;
}
