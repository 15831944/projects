/*
 * DebugTools.h -  һЩ�����õĺ�
 * 
 * Copyright (C) 2006 Zhangzhen
 * 
 */
#include "StdAfx.h"

#include <iostream>
#include "DebugTools.h"

using namespace std;

#ifdef _DEBUG

#ifndef _CONSOLE //����ͼ�ν��棬��Ҫ�½�һ��Console
	static struct INITDEBUG InitDebug;
#endif //_WIN32


FILE* fDebugLog = NULL;

struct DEBUG_LOG_FILE 
{
	DEBUG_LOG_FILE()
	{
		TCHAR szDebugFile[256];
		time_t tStarted = time(NULL);
		_tcsftime(szDebugFile, sizeof(szDebugFile)/sizeof(TCHAR), _T("DebugLog%Y%m%d.log"), localtime(&tStarted));
		fDebugLog = fopen((char*)szDebugFile, "ab");
	}
	~ DEBUG_LOG_FILE()
	{
		if(fDebugLog != NULL)
		{
			fclose(fDebugLog);
			fDebugLog = NULL;
		}
	}
} DebugLogFile;

void DebugOutput(char* tip,char* format,...)
{
	va_list ap;
	
	fprintf(stderr, tip);
	fprintf(stderr, ":");

	va_start(ap, format);
	vfprintf(stderr, format, ap);
	va_end(ap);
}

void DebugPrintf(char* format,...)
{
	va_list ap;
 
	va_start(ap, format);
	vfprintf(stderr, format, ap);
	va_end(ap);
}

void DebugLogPrintf(char* format,...)
{
	va_list ap;
	time_t lnow;
	time(&lnow);
	char szTime[256];
	strftime(szTime, 256, "%Y-%m-%d %H:%M:%S", localtime(&lnow));
	fprintf(fDebugLog, szTime);
	va_start(ap, format);
	vfprintf(fDebugLog, format, ap);
	va_end(ap);
	fprintf(fDebugLog, "\n");
	fflush(fDebugLog);
}

/**
 * DebugDump:
 * @tip: tip message
 * @lp: pointer to memory region.
 * @len: length of memory region in bytes.
 * 
 * Writes a dump of a memory region to stdout.  The dump contains a
 * hexadecimal and an ascii representation of the memory region.
 * 
 **/
void DebugDump(char* tip, void*lp, long len)
{
   char * p;
   long i, j, start;
   char Buff[80];
   char stuffBuff[10];
   char tmpBuf[10];
	
   DebugPrintf(tip);
   DebugPrintf("Dump of %ld(%lx) bytes\n",len, len);
   start = 0L;
   while (start < len)
   {
    /* start line with pointer position key */
      p = (char*)lp + start;
      sprintf(Buff,"%p: ",p);
  
    /* display each character as hex value */
      for (i=start, j=0; j < 16; p++,i++, j++)
      {
         if (i < len)
         {
            sprintf(tmpBuf,"%X",((int)(*p) & 0xFF));
  
            if (strlen((char *)tmpBuf) < 2)
            {
               stuffBuff[0] = '0';
               stuffBuff[1] = tmpBuf[0];
               stuffBuff[2] = ' ';
               stuffBuff[3] = '\0';
            } else
            {
               stuffBuff[0] = tmpBuf[0];
               stuffBuff[1] = tmpBuf[1];
               stuffBuff[2] = ' ';
               stuffBuff[3] = '\0';
            }
            strcat(Buff, stuffBuff);
         } else
            strcat(Buff," ");
         if (j == 7) /* space between groups of 8 */
            strcat(Buff," ");
      }
  
    /* fill out incomplete lines */
      for(;j<16;j++)
      {
         strcat(Buff,"   ");
         if (j == 7)
            strcat(Buff," ");
      }
      strcat(Buff,"  ");
  
    /* display each character as character value */
      for (i=start,j=0,p=(char*)lp+start;
         (i < len && j < 16); p++,i++, j++)
      {
         if ( ((*p) >= ' ') && ((*p) <= '~') )   /* test displayable */
            sprintf(tmpBuf,"%c", *p);
         else
            sprintf(tmpBuf,"%c", '.');
         strcat(Buff,tmpBuf);
         if (j == 7)   /* space between groups of 8 */
            strcat(Buff," ");
      }
      DebugPrintf("%s\n", Buff);
      start = i;  /* next line starting byte */
   }
}

#else //_DEBUG

void DebugOutput(char* tip,char* format,...)
{

}

void DebugPrintf(char* format,...)
{

}

void DebugLogPrintf(char* format,...)
{

}

void DebugDump(char* tip, void*lp, long len)
{

}

#endif //_DEBUG
