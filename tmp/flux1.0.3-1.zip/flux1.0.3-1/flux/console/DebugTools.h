/*
 * DebugTools.h -  һЩ�����õĺ�
 * 
 * Copyright (C) 2006 Zhangzhen
 * 
 */

#ifndef DEBUGTOOLS_H
#define DEBUGTOOLS_H

#include <stdio.h>
#include <stdarg.h>

#include "GUIConsole.h"

/*
 * define DBG for debug easy
 */
#undef DBG_MSG
#undef DBG1
#undef DBG2
#undef DBG3

#ifdef _DEBUG
//	#define DBG(fmt, args...) fprintf(stderr,"File:" __FILE__ " Line: %d Data:" fmt, __LINE__, ##args)
	#define DBG_PRINT	 DebugPrintf
	#define DBG_LOG_PRINT	 DebugLogPrintf				//����־�������
	#define DBG_OUTPUT	 DebugOutput
	#define DBG_MSG	 fprintf(stderr,"File:<" __FILE__ "> Line: <%d> \nData:", __LINE__),DebugPrintf
	#define DBG(fmt) fprintf(stderr,"File:" __FILE__ " Line: %d \nData:" fmt, __LINE__)
	#define DBG1(fmt, arg1) fprintf(stderr,"File:" __FILE__ " Line: %d \nData:" fmt, __LINE__, arg1)
	#define DBG2(fmt, arg1, arg2) fprintf(stderr,"File:" __FILE__ " Line: %d \nData:" fmt, __LINE__, arg1, arg2)
	#define DBG3(fmt, arg1, arg2, arg3) fprintf(stderr,"File:" __FILE__ " Line: %d \nData:" fmt, __LINE__, arg1, arg2, arg3)
#else
	#define DBG_PRINT		/* nothing: it's a placeholder */
	#define DBG_LOG_PRINT	/* nothing: it's a placeholder */
	#define DBG_OUTPUT		/* nothing: it's a placeholder */
	#define DBG_MSG			/* nothing: it's a placeholder */
	#define DBG(fmt)		/* nothing: it's a placeholder */
	#define DBG1(fmt, arg1)
	#define DBG2(fmt, arg1, arg2)
	#define DBG3(fmt, arg1, arg2, arg3)
#endif	//DEBUG

#ifndef ASSERT
#include <crtdbg.h>
#define ASSERT _ASSERT
#endif //ASSERT

void DebugOutput(char* tip,char* format,...);
void DebugPrintf(char* format,...);
void DebugLogPrintf(char* format,...);
void DebugDump(char* tip,void*lp, long len);

struct INITDEBUG 
{
	INITDEBUG()
	{
#ifdef _DEBUG
		RedirectIOToConsole();
#endif //_DEBUG
	}
};

#ifdef  _USE_MFC

#define CHECK_OBJ(pObj)		if (pObj != NULL) ASSERT_VALID(pObj)
#define CHECK_PTR(ptr)		ASSERT( ptr == NULL || AfxIsValidAddress(ptr, sizeof(*ptr)) );
#define CHECK_ARR(ptr, len)	ASSERT( (ptr == NULL && len == 0) || (ptr != NULL && len != 0 && AfxIsValidAddress(ptr, len)) );
#define	CHECK_BOOL(bVal)	ASSERT( (UINT)(bVal) == 0 || (UINT)(bVal) == 1 );

#define	CRASH_HERE()		(*((int*)NULL)

#endif  // _USE_MFC

#endif //DEBUGTOOLS_H