
// fluxDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "SystemInfo.h"
#include <map>
#include <vector>
#include <afxcoll.h>
#include <boost/thread.hpp>

typedef struct tagTask
{
	unsigned int RunCount;
	DWORD pid;
	tagTask(DWORD p)
	{
		memset(this, 0X0, sizeof(tagTask));
		pid = p;
	}
}Task, *pTask;


// CfluxDlg �Ի���
class CfluxDlg : public CDialog
{
// ����
public:
	CfluxDlg(CWnd* pParent = NULL);	// ��׼���캯��
	~CfluxDlg();	

// �Ի�������
	enum { IDD = IDD_FLUX_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	
	afx_msg void OnBnClickedButton1();
	afx_msg void OnEnChangeEdit1();

	CButton m_start;
	CButton m_stop;
	CEdit   m_proName;
	CComboBox m_proPid;
	


	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	CButton m_copy;
	CEdit m_ResultControl;

	afx_msg void OnClose();
	afx_msg void OnBnClickedCancel();
protected:
	virtual void OnOK();
	virtual void OnCancel();

private:
	void GetMonitorData(CString &data, DWORD pid);
	//�����̣߳���ɼ������
	static unsigned int _stdcall WorkThread(LPVOID param);
	unsigned int _stdcall WorkThread();
	//���̿�ʼ��¼�߳�
	static unsigned int _stdcall RecordStartDataThread(LPVOID param);
	unsigned int _stdcall RecordStartDataThread();
private:
	CSystemInfo m_systemInfo;
	HANDLE		m_hThreadRecord;
	HANDLE		m_hThreadWork;
	HANDLE		m_hEvent;
	BOOL		m_IsStartSta;
	BOOL		m_Finish;
	//BOOL		m_bFlag;
	CString		m_Data;
	DWORD		m_pid;
	std::vector<Task>   m_TaskList;
	boost::mutex		m_MutexLock;
	boost::mutex        m_RecodeMutex;
	std::map<DWORD, std::vector<CString>> m_recodeData;  //���ڼ�¼ǰ30������
	//boost::mutex m_tmp;
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
